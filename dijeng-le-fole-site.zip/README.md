
# 🌍 Dijeng Le Fole – African Food & Storytelling Website

This is the official website for **Dijeng Le Fole**, built using **React** and **Sanity CMS**.

---

## 🚀 Features
- African cultural design and visuals
- Dynamic shop powered by Sanity CMS
- Community storytelling and video section
- Mobile-friendly and responsive
- Deployed easily with Vercel

---

## 🛠 How to Run the Project

### 1. Setup Sanity CMS

- Go to [https://sanity.io](https://sanity.io)
- Create a new project with dataset `production`
- Define schemas: `product`, `story`, `eventFood`
- Deploy studio: `sanity deploy`

### 2. Install and Run Locally

```bash
npm install
npm run dev
```

> Make sure to create `.env.local` with:
```
SANITY_PROJECT_ID=dijenglefole
```

---

## 🌐 Deployment

Use [https://vercel.com](https://vercel.com):

1. Import GitHub repo
2. Add env variable `SANITY_PROJECT_ID`
3. Click **Deploy**

---

## 📦 Folder Contents

- `index.jsx` – Full website source code
- `README.md` – Setup + launch instructions

---

## ✅ Admin Access (CMS)
Once your Sanity Studio is deployed, the owner can:
- Log in securely
- Add/edit/remove products
- Publish stories and cultural event content
