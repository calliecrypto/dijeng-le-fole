
import React, { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Instagram, Facebook, Youtube } from "lucide-react";
import imageUrlBuilder from "@sanity/image-url";
import { createClient } from "@sanity/client";

const client = createClient({
  projectId: "dijenglefole", // ✅ valid Sanity Project ID (replace with yours if different)
  dataset: "production",
  apiVersion: "2023-01-01",
  useCdn: true
});

const builder = imageUrlBuilder(client);
function urlFor(source) {
  return builder.image(source);
}

export default function Home() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    client.fetch(`*[_type == "product"]`).then(data => setProducts(data));
  }, []);

  return (
    <main className="min-h-screen bg-[url('/african-pattern.jpg')] bg-cover bg-fixed text-white">
      {/* Navigation */}
      <header className="bg-black bg-opacity-80 p-4 flex justify-between items-center">
        <div className="flex items-center space-x-4">
          <img src="/logo-pot.png" alt="Dijeng Le Fole Logo" className="h-10 w-10 rounded-full" />
          <h1 className="text-2xl font-bold">DIJENG LE FOLE</h1>
        </div>
        <nav className="space-x-4">
          <a href="#events" className="hover:underline">Events</a>
          <a href="#shop" className="hover:underline">Shop</a>
          <a href="#stories" className="hover:underline">Stories</a>
          <a href="#contact" className="hover:underline">Contact</a>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="bg-black bg-opacity-60 p-8 text-center">
        <img src="/hero-food-visual.jpg" alt="African Meal" className="mx-auto mb-6 rounded-xl max-h-96 w-full object-cover" />
        <h1 className="text-4xl md:text-6xl font-bold mb-4">DIJENG LE FOLE</h1>
        <p className="text-xl italic mb-6">"Let us not forget, we eat what we grow."</p>
        <p className="max-w-3xl mx-auto text-lg">
          Promoting healing and wellbeing through African food. Sharing stories from African communities and honoring indigenous food traditions.
        </p>
      </section>

      {/* Events Section */}
      <section id="events" className="bg-white bg-opacity-90 text-black p-8">
        <h2 className="text-3xl font-bold mb-4">Food According to Events</h2>
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <ul className="list-disc pl-5 space-y-2">
              <li><strong>Weddings:</strong> Jollof rice, Samp & Beans, Roast meats, Traditional beer</li>
              <li><strong>Funerals:</strong> Sorghum porridge, Stews, Seasonal vegetables</li>
              <li><strong>Coming-of-age:</strong> Roasted maize, Herbal teas, Millet porridge</li>
              <li><strong>Community gatherings:</strong> Braais, Shared stews, Flatbreads</li>
            </ul>
          </div>
          <div>
            <img src="/african-event-meals.jpg" alt="African Event Meals" className="rounded-xl shadow-lg w-full h-auto" />
          </div>
        </div>
      </section>

      {/* Shop Section */}
      <section id="shop" className="p-8">
        <h2 className="text-3xl font-bold mb-4">Shop</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {products.map(product => (
            <Card key={product._id}>
              <CardContent className="p-4">
                <img src={urlFor(product.image).url()} alt={product.title} className="mb-2 rounded-xl" />
                <h3 className="text-xl font-semibold">{product.title}</h3>
                <p>{product.description}</p>
                <Button className="mt-2">Buy Now - R{product.price}</Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Storytelling Section */}
      <section id="stories" className="bg-white bg-opacity-90 text-black p-8">
        <h2 className="text-3xl font-bold mb-4">Community Food Stories</h2>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-black bg-opacity-10 p-4 rounded-xl">
            <h3 className="text-xl font-semibold mb-2">The Healing Soup of Botswana</h3>
            <p>This soup has been passed down through generations and used for cleansing after childbirth...</p>
            <iframe className="mt-2 w-full h-64 rounded-xl" src="https://www.youtube.com/embed/samplevideo" allowFullScreen></iframe>
          </div>
          <div className="bg-black bg-opacity-10 p-4 rounded-xl">
            <h3 className="text-xl font-semibold mb-2">Namibian Herbal Teas</h3>
            <p>These teas are brewed from native plants known for their calming effects and digestive benefits...</p>
            <iframe className="mt-2 w-full h-64 rounded-xl" src="https://www.youtube.com/embed/samplevideo2" allowFullScreen></iframe>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="bg-black bg-opacity-70 text-white p-8 text-center">
        <h2 className="text-3xl font-bold mb-4">Connect with Dijeng</h2>
        <div className="flex justify-center space-x-4 mb-4">
          <a href="https://instagram.com/dijenglefole" aria-label="Instagram"><Instagram /></a>
          <a href="https://facebook.com/dijenglefole" aria-label="Facebook"><Facebook /></a>
          <a href="https://youtube.com/@dijenglefole" aria-label="YouTube"><Youtube /></a>
        </div>
        <p>Phone: 079 120 0665</p>
        <p>Email: info@dijenglefole.com</p>
      </section>

      {/* Footer */}
      <footer className="bg-black bg-opacity-80 p-4 text-center text-sm">
        <p>&copy; {new Date().getFullYear()} Dijeng Le Fole. All rights reserved.</p>
      </footer>
    </main>
  );
}
